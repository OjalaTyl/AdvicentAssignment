﻿/*
 * Author: Tyler Ojala
 * Purpose: Provides context of CollegeCost to the controller of CollegeCost.
 * It also loads the database with the csv file.
 */
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AdvicentAssignment.Controllers;
using LumenWorks.Framework.IO.Csv;
using Microsoft.EntityFrameworkCore;

namespace AdvicentAssignment.Models
{
    public class CollegeCostContext : DbContext
    {
        public DbSet<CollegeCost> CollegeCostDatabase { get; set; }

        // Constructor for this class. Loads the database 
        public CollegeCostContext(DbContextOptions<CollegeCostContext> options) : base(options)
        {
            LoadDB();
        }


        /* Loads the database with the csv file.
         * The method first loads a table with the content of the csv file. That table is
         * then used to create each entry of the college costs in the csv.
         */
        private void LoadDB()
        {
            var csvTable = new DataTable();
            using (var csvReader = new CsvReader(new StreamReader(System.IO.File.OpenRead("../../AdvicentAssignment/AdvicentAssignment/Files/CollegeCosts.csv")),true))
            {
                csvTable.Load(csvReader);
                
            }

            string name;
            decimal instate;
            decimal outstate;
            decimal roomandboard;

            for (int x = 0; x < csvTable.Rows.Count; x++)
            {
                name = csvTable.Rows[x][0].ToString();

                try
                {
                    instate = Decimal.Parse(csvTable.Rows[x][1].ToString());
                }
                catch(Exception e)
                {
                    instate = 0;
                }
                try
                {
                    outstate = Decimal.Parse(csvTable.Rows[x][2].ToString());
                }
                catch (Exception e)
                {
                    outstate = 0;
                }
                try
                {
                    roomandboard = Decimal.Parse(csvTable.Rows[x][3].ToString());
                }
                catch (Exception e)
                {
                    roomandboard = 0;
                }

                CollegeCostDatabase.Add(new CollegeCost(name, instate, outstate, roomandboard));
            }
        }

    }
}