﻿/*
 * Author: Tyler Ojala
 * Purpose: Model to represent colleges and their costs.
 */
public class CollegeCost
{
	public string ID { get; set; }
	public decimal instate { get; set; }
	public decimal outstate { get; set; }
	public decimal roomandboard { get; set; }

	//Basic constructor for this class
	public CollegeCost()
    {

    }

	//Contructor that sets all variables contained in the class. 
	public CollegeCost(string ID, decimal instate, decimal outstate, decimal roomandboard)
    {
		this.ID = ID;
		this.instate = instate;
		this.outstate = outstate;
		this.roomandboard = roomandboard;
    }
}
